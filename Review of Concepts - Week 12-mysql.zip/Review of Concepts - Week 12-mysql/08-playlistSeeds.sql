-- // * Create a database called `playlistDB`, then create a table inside of this database called `songs`. The songs table should have four columns:
-- //   1. id
-- //   2. title
-- //   3. artist
-- //   4. genre
-- // * Make sure you add some songs to this table so you have actual data to work with.


DROP DATABASE IF EXISTS playlistDB;
CREATE DATABASE playlistDB;

USE playlistDB;

CREATE TABLE songs(
  id INT NOT NULL AUTO_INCREMENT,
  title VARCHAR(45) NULL,
  artist VARCHAR(45) NULL,
  genre VARCHAR(45) NULL,
  PRIMARY KEY (id)
);

INSERT INTO songs (title, artist, genre)
VALUES ("Human", "Krewella", "Dance");

INSERT INTO songs (title, artist, genre)
VALUES ("TRNDSTTR","Black Coast", "Dance");

INSERT INTO songs (title, artist, genre)
VALUES ("Who's Next", "The Who", "Classic Rock");

INSERT INTO songs (title, artist, genre)
VALUES ("Yellow Submarine", "The Beatles", "Classic Rock");

-- REVIEW OF CONCEPTS:
-- 1. using Javascript file to connect to mySQLWorkbench via node.js and npm package manager mysql. playlistRead.sql must be executed in mySQLWorkbench for queries via mysql npm package to work
-- 2. .sql file provides schema for database and tables within DATABASE.

