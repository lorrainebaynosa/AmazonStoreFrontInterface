
// * Now create code that prints songs of a specific genre/artist to the terminal.

// * BONUS: Use 'placeholder' values or string concatenation to build a MySQL query which allows you to change pieces of the query on the fly (e.g. using a variable to build the `WHERE` clause, instead of a static string).

//   * There are a couple different ways to accomplish this task, but the most common one can be found within the [documentation for the MySQL package](https://github.com/mysqljs/mysql#performing-queries).


var mysql = require("mysql");

var connection = mysql.createConnection({
  host: "localhost",

  // Your port; if not 3306
  port: 3306,

  // Your username
  user: "root",

  // Your password
  password: "lazyjack",
  database: "playlistDB"
});


connection.connect(function(err) {
  if (err) throw err;
  console.log("connected as id " + connection.threadId);
  queryAllSongs();
  queryDanceSongs();
});
// REVIEW OF CONCEPTS:
// 1. must call/invoke functions queryAllSongs and queryDanceSongs for them to run/execute & show up on the terminal

function queryAllSongs() {
  connection.query("SELECT * FROM songs", function(err, res) {
    for (var i = 0; i < res.length; i++) {
      console.log(res[i].id + " | " + res[i].title + " | " + res[i].artist + " | " + res[i].genre);
    }
    console.log("-----------------------------------");
  });
}
// REVIEW OF CONCEPTS
// 1. id, title, artist, and genre are columns from playlistDB.songs
// 2. err === error; res === results


// * We are going to print playlists to the console based upon the genre or artist.

function queryDanceSongs() {
  var query = connection.query("SELECT * FROM songs WHERE genre=?", ["Dance"], function(err, res) {
    for (var i = 0; i < res.length; i++) {
      console.log(res[i].id + " | " + res[i].title + " | " + res[i].artist + " | " + res[i].genre);
    }
    connection.end();
  });

// REVIEW OF CONCEPTS:
// 1. Here we select genre = "Dance"

  // logs the actual query being run (for queryDanceSongs)
  console.log(query.sql);

}

// REVIEW OF CONCEPTS: To run in node.js, ensure you have changed your password for mySQL: 
// connecting node.js and combining with a database "mysql" npm package
// mysql does not understand JS. mysql just understands SQL
// TO USE mysql npm package, enter the following in the terminal:
  // 1. $ npm init (enter this in command line & keep clicking ENTER). Creates package.json (NOTE: YOU DON'T need to enter npm init if you already have package.json with mysql as a dependency.)
  // 2. $ npm install mysql --save (npm is the Node.js package manager). This downloads the library and installs it in the node_modules folder; and saves it as a DEPENDENCY in package.json file.
  // 3. after installing mysql, the following modules were created: node_modules, package-lock.json, and package.json
  // 4. package.json lists mysql as a dependency. We want to have package dependency.
  // 5. ensure connection.end(); is specified; otherwise, connection will remain open.

  // to test code above, by entering following in terminal after running npm init and npm install; and executing code for playlistSeeds.sql: node playlistRead.js	
  // RETURNS:
//   connected as id 36
// SELECT * FROM songs WHERE genre='Dance'
// 1 | Human | Krewella | Dance
// 2 | TRNDSTTR | Black Coast | Dance
// 3 | Who's Next | The Who | Classic Rock
// 4 | Yellow Submarine | The Beatles | Classic Rock
// -----------------------------------
// 1 | Human | Krewella | Dance
// 2 | TRNDSTTR | Black Coast | Dance


