-- Drops the animals_db if it exists currently --
DROP DATABASE IF EXISTS animals_db;
-- Creates the "animals_db" database --
CREATE DATABASE animals_db;

-- Makes it so all of the following code will affect animals_db --
USE animals_db;

-- Creates the table "people" within animals_db --
CREATE TABLE people (
  -- Makes a string column called "name" which cannot contain null --
  name VARCHAR(30) NOT NULL,
  -- Makes a boolean column called "has_pet" which cannot contain null --
  has_pet BOOLEAN NOT NULL,
  -- Makes a sting column called "pet_name" --
  pet_name VARCHAR(30),
  -- Makes an numeric column called "pet_age" --
  pet_age INTEGER(10)
);

-- Creates new rows containing data in all named columns --
INSERT INTO people (name, has_pet, pet_name, pet_age)
VALUES ("Ahmed", TRUE, "Rockington", 100);

INSERT INTO people (name, has_pet, pet_name, pet_age)
VALUES ("Ahmed", TRUE, "Rockington", 100);

INSERT INTO people (name, has_pet, pet_name, pet_age)
VALUES ("Jacob", TRUE, "Misty", 10);

INSERT INTO people (name, has_pet)
VALUES ("Peter", false);

-- Updates the row where the column name is peter --
UPDATE people
SET has_pet = true, pet_name = "Franklin", pet_age = 2
WHERE name = "Peter";


-- REVIEW OF CONCEPTS 
-- A database is an organized collection of data, generally stored and accessed electronically from a computer system. The database management system (DBMS) is the software that interacts with end users, applications, and the database itself to capture and analyze the data. There are four types of DBMS - hierarchical, network, object-oriented, and relational. Relational DBMS uses a structure that allows users to identify and access data in relation to another piece of data in a database. https://www.youtube.com/watch?v=vIH-f9wQUQs
-- A relational database refers to a database that stores data in a structured format, using rows and columns. This makes it easy to locate and access specific values within the database. It is "relational" because the values within each table are related to each other. Tables may also be related to other tables. The relational structure makes it possible to run queries across multiple tables at once. https://techterms.com/definition/rdbms
-- While a relational database describes the type of database an RDMBS manages, the RDBMS refers to the database program itself. It is the software that executes queries on the data, including adding, updating, and searching for values. An RDBMS may also provide a visual representation of the data. For example, it may display data in a tables like a spreadsheet, allowing you to view and even edit individual values in the table. Some RDMBS programs allow you to create forms that can streamline entering, editing, and deleting data. https://techterms.com/definition/rdbms. Most well known DBMS applications fall into the RDBMS category. Examples include Oracle Database, MySQL, Microsoft SQL Server, and IBM DB2.
-- mySQL is the most popular, open-source, RDBMS powered by Oracle, that can be used to store data and provide various actions (put data into a database). MySQL uses a client-server model, which means database runs on a server. Data is accessed over the network by clients and workstations. https://www.youtube.com/watch?v=DCaA1-EcTMk
-- MySQL provides a graphical management tool or GUI, MySql workbench, which helps us interact with MySql server database. mySQL IS NOT MySQL workbench. However, the schemas we see within the MySql workbench are in mySQL.
-- Structured Query Language(SQL) is a domain-specific language used in programming to manage data held in a relational database management system (RDBMS) or a relational data stream management system. Useful in handling structured data where there are relations between different entities of the data. SQL statements are used to perform CRUD operations in mySQL using SQL. CRUD refers to the basic operations in any RDBMS, Create, Read, Update, and Delete.  
-- need to have a sql document to be able to copy code into MySQLWorkbench since mySQL is only able to translate code in SQL. animalsDB.sql sets up structure of database (schema) in mySQL.
-- we're using mySQL database set up locally via connection to a local server, hostname 127.0.0.1 and port 3306, so need to have mySQL up and running (connection to the server working) in order for use to translate animalsDB.sql; the server receives request in SQL language format (animalsDB.sql) and sends back responses in SQL format (actual display of schema outlined in code)
-- the database server may be the back-end of the database application (the instance), or it may be the hardware computer that hosts the instance. Sometimes, it may even refer to the combination of both hardware and software. A Database Server is a computer in a LAN that is dedicated to database storage and retrieval. The database server holds the Database Management System (DBMS) and the databases. Upon requests from the client machines, it searches the database for selected records and passes them back over the network. A database server can be defined as a server dedicated to providing database services. Such a server runs the database software. A database server can typically be seen in a client-server environment where it provides information sought by the client systems. 

--SQL uses CLAUSES to dictate what actions should be performed. The CLAUSES are highlighted in BLUE in this activity. ORDER of clauses matters. Specify the following specific to your query:
-- 1. USE [name of database];
-- 2. SELECT [columns to be included], where * stands for all columns; if you specify specific columns, they will appear sequentially from left to right (i.e., you can dictate how the final table will appear)
-- 3. FROM [table]
-- 4. WHERE [condition to filter data]
-- 5. ORDER BY [column] 
-- 6. LIMIT [number of records you want to display]
-- In MySQL, every statement must be terminated with a semicolon.

-- (INSERTING MULTIPLE SINGLE RECORDS): alternative to writing out "3" INSERT INTO as noted above:
-- INSERT INTO people (name, has_pet, pet_name, pet_age)
-- VALUES 
--   ("Ahmed", TRUE, "Rockington", 100),
--   ("Ahmed", TRUE, "Rockington", 100),
--   ("Jacob", TRUE, "Misty", 10);

-- DROP DATABASE IF EXISTS: caution as it will delete all data.
--
-- INSERT INTO [table] (column#1, column#2, column#3, column#4)
-- VALUES (values for each column separated by comma);

-- SQL DATA TYPES:
-- In MySQL there are three main data types: string, numeric, and date and time. https://www.w3schools.com/sql/sql_datatypes.asp 
-- STRING DATA TYPES:
-- 1. VARCHAR((50): variable length STRING data type but only holds the characters you assign to it & only stores number of characters needed; (50) === max 50 characters; can store leading zeroes so use VARCHAR with phone numbers and zip codes; 
-- 2. CHAR: A FIXED length string (can contain letters, numbers, and special characters). The size parameter specifies the column length in characters - can be from 0 to 255. Default is 1DON'T USE CHAR because it wastes storage space;
-- 3. SET(val1, val2, val3, ...): A string object that can have 0 or more values, chosen from a list of possible values. You can list up to 64 values in a SET list
-- NUMERIC DATA TYPES:
-- 1. INT(11): Integer (max 11 characters)
-- DATE & TIME DATA TYPES:

-- NOT NULL: By default, a column can hold NULL values. The NOT NULL constraint enforces a column to NOT accept NULL values. This enforces a field to always contain a value, which means that you cannot insert a new record, or update a record without adding a value to this field. https://www.w3schools.com/sql/sql_notnull.asp
-- BOOLEAN: MySQL does not have built-in Boolean type. However, it uses TINYINT(1) instead. To make it more convenient, MySQL provides BOOLEAN or BOOL as the synonym of TINYINT(1).In MySQL, zero is considered as false, and non-zero value is considered as true. To use Boolean literals, you use the constants TRUE and FALSE that evaluate to 1 and 0 respectively. http://www.mysqltutorial.org/mysql-boolean/
-- VALUES ("Peter", false), where false evaluates to 0 in the table cell and updates to 1 with UPDATE clause

-- SEEDING data: adding data into your database (in production) via user interaction with application to generate content
-- SEEDS file: copy of data that can go into your database (copy of production database)


