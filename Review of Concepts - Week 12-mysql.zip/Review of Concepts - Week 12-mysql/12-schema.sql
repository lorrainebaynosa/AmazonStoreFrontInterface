-- * It's time to test your skills in creating databases and tables as you create a database called `top_songsDB` which will eventually house all of the music data contained within `TopSongs.csv`
-- * All of your code should be written and saved within a filed called `schema.sql` so that you can use this same code later should the need ever arise

DROP DATABASE IF EXISTS top_songsDB;

CREATE DATABASE top_songsDB;

USE top_songsDB;
-- REVIEW OF CONCEPTS: specify database you will be using to create table.

-- * Within your database create a table called `Top5000` and create columns capable of holding all of the data contained within `TopSongs.csv` properly.
CREATE TABLE Top5000 (
    rating INT NOT NULL,
    artist VARCHAR (30) NOT NULL,
    song_name VARCHAR (30) NOT NULL,
    date_release INT NULL,
    raw_rating DECIMAL (10,4) NULL,
    US_rating  DECIMAL (10,4) NULL,
    UK_rating DECIMAL (10,4) NULL,
    world_rating DECIMAL (10,4) NULL,
    misc_rating DECIMAL (10,4) NULL
);

-- 1,Bing Crosby,White Christmas,1942,39.903,23.929,5.7,2.185,0.54

-- INSERT INTO Top5000 (rating, artist, song_name, date_release, raw_rating, US_rating, UK_rating, world_rating, misc_rating)
-- VALUES (data from row);


-- * HINT: Try to have your table's columns match those within the CSV file as closely as possible or else you may find the next step in this assignment more difficult than it would otherwise be

-- * BONUS: Create a `seeds.sql` file that contains the data for the first three songs found within `TopSongs.csv`


-- * BONUS: Look into how MySQL Workbench can import and export data files. What file types does it accept? How does it convert the data?

-- REVIEW OF CONCEPTS: TO IMPORT DATA from VS code into mySQL Workbench. In mySQL Workbench,
-- 1. click on table into which you want to import data.
-- 2. Right click on that table and then select:
-- 3. Table Data Import Wizard
-- 4. Select file you want to open (browse and find it). This is the file you will be using to see the table Top5000;
-- 5. click USE EXISTING TABLE and run

-- NOTE: In order to seed a file into a table/database, you must have created the schema/structure for the table. Ensure the #rows match exactly

-- mySQL Workbench: shows
-- SELECT * FROM top_songsDB.Top5000; which means SELECT all columns from database.table