-- * BONUS: Start looking into the concept of joins in SQL

-- * Make a new database called "programming_db" and switch into it for this activity

-- Drops the programming_db if it already exists --
DROP DATABASE IF EXISTS programming_db;
-- Create a database called programming_db --
CREATE DATABASE programming_db;

USE programming_db;

-- * Create a table called "programming_languages" which includes a primary key named "id" which will automatically increment which each new row created, a string column called "languages," and a numeric column called "rating."
-- * BONUS: Study up on how to add columns to a table and then create a boolean column called "mastered" which has a default value of true

CREATE TABLE programming_languages(
  -- Creates a numeric column called "id" which will automatically increment its default value as we create new rows. --
  id INTEGER(11) AUTO_INCREMENT NOT NULL,
  language VARCHAR(20),
  rating INTEGER(11),
  -- Creates a boolean column called "mastered" which will automatically fill --
  -- with true when a new row is made and the value isn't otherwise defined. --
  mastered BOOLEAN DEFAULT true,
  PRIMARY KEY (id)
);

-- * Insert some data into the table and then modify the data using the id column.
-- Creates new rows
INSERT INTO programming_languages (language, rating)
VALUES ("HTML", 95);

INSERT INTO programming_languages (language, rating)
VALUES ("JS", 99);

INSERT INTO programming_languages (language, rating)
VALUES ("JQuery", 98);

INSERT INTO programming_languages (language, rating)
VALUES ("MySQL", 70);

-- REVIEW OF CONCEPTS:
-- 1. id INTEGER(11) AUTO_INCREMENT NOT NULL, 
-- note how AUTO_INCREMENT precedes NOT NULL in Activity04 
-- but in Activity02, NOT NULL precedes AUTO_INCREMENT
-- id INTEGER NOT NULL AUTO_INCREMENT,
-- summary: we have 2 options for ensuring and AUTO_INCREMENT with NOT NULL
-- 2. PRIMARY KEY: a field in a table which uniquely identifies each row/record in a database table. Primary keys must contain unique values. A primary key column cannot have NULL values. A table can have only one primary key, which may consist of single or multiple fields. https://www.tutorialspoint.com/sql/sql-primary-key.htm
-- NOTE syntax for setting primary key to id: PRIMARY KEY (id)
-- 3. BOOLEAN DEFAULT true translates into 1 in the cell in mySQLWorkbench

-- DELETE FROM [table]
-- WHERE [condition]
-- if trying to delete specific record, use primary key as identifier

