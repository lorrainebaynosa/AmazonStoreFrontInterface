DROP DATABASE IF EXISTS ice_creamDB;

CREATE DATABASE ice_creamDB;

USE ice_creamDB;

CREATE TABLE products (
  id INT NOT NULL AUTO_INCREMENT,
  flavor VARCHAR(45) NULL,
  price DECIMAL(10,2) NULL,
  quantity INT NULL,
  PRIMARY KEY (id)
);
-- REVIEW OF CONCEPTS:
-- DROP DATABASE IF EXISTS ice_creamDB; deletes database entirely CAUTION
-- SCHEMA: refers to structure of table
-- where INT NOT NULL is a data type in SQL; INT will only accept integers, where NOT NULL means you have to have this value but this is autocreated
-- where default is NULL so can give a NULL value
-- where id, flavor, price, & quantity are column names
-- where VARCHAR(45) means text can't have more than 45 characters
-- where DECIMAL(10,2) means up to 10 digits, up to 2 decimal places
-- primary key should be your id (starts at 1)

INSERT INTO products (flavor, price, quantity)
VALUES ("vanilla", 2.50, 100);

INSERT INTO products (flavor, price, quantity)
VALUES ("chocolate", 3.10, 120);

INSERT INTO products (flavor, price, quantity)
VALUES ("strawberry", 3.25, 75);

-- REVIEW OF CONCEPTS:
-- ### Alternative way to insert more than one row
-- INSERT INTO products (flavor, price, quantity)
-- VALUES ("vanilla", 2.50, 100), ("chocolate", 3.10, 120), ("strawberry", 3.25, 75);
