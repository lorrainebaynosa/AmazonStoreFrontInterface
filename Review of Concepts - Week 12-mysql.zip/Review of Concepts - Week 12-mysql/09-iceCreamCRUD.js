// * It's time to start making our playlist application a little more functional through including all four C.R.U.D elements within it.


// * BONUS: After successfully adding CRUD to your application, it's time to test your mettle and see if you can make it so this app is more dynamic. Add the ability for users to dynamically input their own data into the database using the Inquirer NPM package.

// * HINT: Recall that you can create MySQL queries which include variables using question marks. Proper usage of this will help you quite a bit.
// * HINT: Remember to take into account the scope of Prompt/Promptly when putting your application together.

var mysql = require("mysql");

var connection = mysql.createConnection({
  host: "localhost",

  // Your port; if not 3306
  port: 3306,

  // Your username
  user: "root",

  // Your password
  password: "lazyjack",
  database: "ice_creamDB"
});

connection.connect(function(err) {
  if (err) throw err;
  console.log("connected as id " + connection.threadId + "\n");
  createProduct();
});

// * Add in some pieces of code that CREATE, UPDATE, and DELETE specific pieces of data from your MySQL database. Make sure to include a READ statement at the end as well to ensure that the changes you are making are working properly.

function createProduct() {
  console.log("Inserting a new product...\n");
  var query = connection.query(
    "INSERT INTO products SET ?",
    {
      flavor: "Rocky Road",
      price: 3.0,
      quantity: 50
    },
    function(err, res) {
      console.log(res.affectedRows + " product inserted!\n");
      // Call updateProduct AFTER the INSERT completes
      updateProduct();
    }
  );

  // logs the actual query being run
  console.log(query.sql);
}

function updateProduct() {
  console.log("Updating all Rocky Road quantities...\n");
  var query = connection.query(
    "UPDATE products SET ? WHERE ?",
    [
      {
        quantity: 100
      },
      {
        flavor: "Rocky Road"
      }
    ],
    function(err, res) {
      console.log(res.affectedRows + " products updated!\n");
      // Call deleteProduct AFTER the UPDATE completes
      deleteProduct();
    }
  );

  // logs the actual query being run
  console.log(query.sql);
}

function deleteProduct() {
  console.log("Deleting all strawberry icecream...\n");
  connection.query(
    "DELETE FROM products WHERE ?",
    {
      flavor: "strawberry"
    },
    function(err, res) {
      console.log(res.affectedRows + " products deleted!\n");
      // Call readProducts AFTER the DELETE completes
      readProducts();
    }
  );
}

function readProducts() {
  console.log("Selecting all products...\n");
  connection.query("SELECT * FROM products", function(err, res) {
    if (err) throw err;
    // Log all results of the SELECT statement
    console.log(res);
    connection.end();
  });
}

// REVIEW OF CONCEPTS: 
// 1. using mysql npm package to connect to iceCreamSees.sql executed in mySQLWorkbench via javascript file and node.js. Ensure password for mySQLWorkbench is updated in var connection function
  // 2. update only updates data that has already been created. Will update all data with flavor Rocky Road to quantity 100
  // 3. concept of showing updateProduct(), deleteProduct(), and readProducts() in the callback is to show you that you can chain callback function with multiple commands
// 4. Create, Read, Update, Destroy(CRUD)
// 5. connecting node.js and combining with a database "mysql" npm package
// mysql does not understand JS. mysql just understands SQL
// TO USE mysql npm package, enter the following in the terminal:
  // a. $ npm init (enter this in command line & keep clicking ENTER). Creates package.json (NOTE: YOU DON'T need to enter npm init if you already have package.json with mysql as a dependency.)
  // b. $ npm install mysql --save (npm is the Node.js package manager). This downloads the library and installs it in the node_modules folder; and saves it as a DEPENDENCY in package.json file.
  // c. after installing mysql, the following modules were created: node_modules, package-lock.json, and package.json
  // d. package.json lists mysql as a dependency. We want to have package dependency: 

  // 6. to test code above, by entering following in terminal after running npm init and npm install; and executing code for iceCreamSeeds.sql (note how console.logs display after one another as we are using asynchronous nodejs.): node iceCreamCRUD.js
  // RETURNS: 
//   connected as id 38

// Inserting a new product...

// INSERT INTO products SET `flavor` = 'Rocky Road', `price` = 3, `quantity` = 50
// 1 product inserted!

// Updating all Rocky Road quantities...

// UPDATE products SET `quantity` = 100 WHERE `flavor` = 'Rocky Road'
// 1 products updated!

// Deleting all strawberry icecream...

// 1 products deleted!

// Selecting all products...

// [ RowDataPacket { id: 1, flavor: 'vanilla', price: 2.5, quantity: 100 },
//   RowDataPacket { id: 2, flavor: 'chocolate', price: 3.1, quantity: 120 },
//   RowDataPacket { id: 4, flavor: 'Rocky Road', price: 3, quantity: 100 } ]
  

