// * Within your groups you are going to be creating a Node application called "Great-Bay" which allows users to create and bid on assorted items, tasks, jobs, or projects.



// * Once your group has put together the basic application, it's time to test your collective skills on some additional functionality, or "addons". Remember to take into consideration the amount of time you have been given when choosing what addons you would like to tackle.

// * Create a sign up and login system that prompts users for a username and password upon loading up the app. **Do not worry about setting up a truly secure database if you choose to tackle this addon. Just worry about building working sign up and login features.**

// * Create a system on the "POST AN ITEM" which allows users to look at the auctions they have created. On this screen they can add new auctions, modify previous auctions, or close bidding on an auction.

// * Create a system which allows users to view all of the auctions of which they are the leading bidder.

// * Create a third option on the main screen which allows administrators to modify the database as they see fit.

// * Create visually appealing tables. This means making dynamic console code and it is a lot harder than it might seem at first so do not think this one is so simple.

// * Create a search function that allows users to look through the database of available auctions to find those that share the specified keyword or username.

// * Get creative! There are a lot of addons to this app which you could create so feel free to work with your group to come up with something not listed above!


var mysql = require("mysql");
var inquirer = require("inquirer");

// create the connection information for the sql database
var connection = mysql.createConnection({
  host: "localhost",

  // Your port; if not 3306
  port: 3306,

  // Your username
  user: "root",

  // Your password
  password: "lazyjack",
  database: "greatBay_DB"
});

// connect to the mysql server and sql database
connection.connect(function(err) {
  if (err) throw err;
  // run the start function after the connection is made to prompt the user
  start();
});

// * The basic application is fairly simple: Upon loading up the program, the user is prompted on whether they would like to "POST AN ITEM" or "BID ON AN ITEM"
// function which prompts the user for what action they should take
function start() {
  inquirer
    .prompt({
      name: "postOrBid",
      type: "list",
      message: "Would you like to [POST] an auction or [BID] on an auction?",
      choices: ["POST", "BID", "EXIT"]
    })
    .then(function(answer) {
      // based on their answer, either call the bid or the post functions
      if (answer.postOrBid === "POST") {
        postAuction();
      }
      else if(answer.postOrBid === "BID") {
        bidAuction();
      } else{
        connection.end();
      }
    });
}

// * If the user selects "POST AN ITEM" they are prompted for an assortment of information regarding the item and then that information is added to the database so that others can bid on it
// function to handle posting new items up for auction
function postAuction() {
  // prompt for info about the item being put up for auction
  inquirer
    .prompt([
      {
        name: "item",
        type: "input",
        message: "What is the item you would like to submit?"
      },
      {
        name: "category",
        type: "input",
        message: "What category would you like to place your auction in?"
      },
      {
        name: "startingBid",
        type: "input",
        message: "What would you like your starting bid to be?",
        validate: function(value) {
          if (isNaN(value) === false) {
            return true;
          }
          return false;
        }
      }
    ])
    .then(function(answer) {
      // when finished prompting, insert a new item into the db with that info
      connection.query(
        "INSERT INTO auctions SET ?",
        {
          item_name: answer.item,
          category: answer.category,
          starting_bid: answer.startingBid || 0,
          highest_bid: answer.startingBid || 0
        },
        function(err) {
          if (err) throw err;
          console.log("Your auction was created successfully!");
          // re-prompt the user for if they want to bid or post
          start();
        }
      );
    });
}

// * If the user selects "BID ON AN ITEM" they are shown a list of all available items and then are prompted to select what they would like to bid on. The console then asks them how much they would like to bid, and their bid is compared to the previous highest bid. If their bid is higher, inform the user of their success and replace the previous bid with the new one. If their bid is lower (or equal), inform the user of their failure and boot them back to the selection screen.
function bidAuction() {
  // query the database for all items being auctioned
  connection.query("SELECT * FROM auctions", function(err, results) {
    if (err) throw err;
    // once you have the items, prompt the user for which they'd like to bid on
    inquirer
      .prompt([
        {
          name: "choice",
          type: "rawlist",
          choices: function() {
            var choiceArray = [];
            for (var i = 0; i < results.length; i++) {
              choiceArray.push(results[i].item_name);
            }
            return choiceArray;
          },
          message: "What auction would you like to place a bid in?"
        },
        {
          name: "bid",
          type: "input",
          message: "How much would you like to bid?"
        }
      ])
      .then(function(answer) {
        // get the information of the chosen item
        var chosenItem;
        for (var i = 0; i < results.length; i++) {
          if (results[i].item_name === answer.choice) {
            chosenItem = results[i];
          }
        }

        // determine if bid was high enough
        if (chosenItem.highest_bid < parseInt(answer.bid)) {
          // bid was high enough, so update db, let the user know, and start over
          connection.query(
            "UPDATE auctions SET ? WHERE ?",
            [
              {
                highest_bid: answer.bid
              },
              {
                id: chosenItem.id
              }
            ],
            function(error) {
              if (error) throw err;
              console.log("Bid placed successfully!");
              start();
            }
          );
        }
        else {
          // bid wasn't high enough, so apologize and start over
          console.log("Your bid was too low. Try again...");
          start();
        }
      });
  });
}

// REVIEW OF CONCEPTS
// 1. https://www.npmjs.com/package/inquirer: 
// var inquirer = require('inquirer');
// inquirer
//   .prompt([
//     /* Pass your questions in here */
//   ])
//   .then(answers => {
//     // Use user feedback for... whatever!!
//   });
// A question object is a hash containing question related values:
// type: (String) Type of the prompt. Defaults: input - Possible values: input, number, confirm, list, rawlist, expand, checkbox, password, editor
// validate: (Function) Receive the user input and answers hash. Should return true if the value is valid, and an error message (String) otherwise. If false is returned, a default error message is provided.
// || === or
// bidAuction function: item_name is column in greatBay_DB.auctions
// The parseInt() function parses a string and returns an integer.
// UPDATE (table), SET ?, WHERE ? is an example of using subqueries with UPDATE statements

// 1. using mysql npm package to connect to greatBaySchema.sql executed in mySQLWorkbench via javascript file and node.js. Ensure password for mySQLWorkbench is updated in var connection function.
// 2. using inquirer npm package to update schema via mySQL npm package.
// 3. TO USE mysql and inquired npm packages, enter the following in the terminal:
  // a. $ npm init (enter this in command line & keep clicking ENTER). Creates package.json (NOTE: YOU DON'T need to enter npm init if you already have package.json with mysql and inquirer as dependency.)
  // b. $ npm install mysql --save (npm is the Node.js package manager). This downloads the library and installs it in the node_modules folder; and saves it as a DEPENDENCY in package.json file.
  // c. $ npm install inquirer 
  // d. after installing mysql and inquirer, the following modules were created: node_modules, package-lock.json, and package.json
  // e. package.json lists mysql and inquirer as dependencies. 
  // 4. to test code above, by entering following in terminal after running npm init and npm install; and executing code for greatBaySchema.sql: node greatBayBasic.js
// ? Would you like to [POST] an auction or [BID] on an auction? POST
// ? What is the item you would like to submit? necklace
// ? What category would you like to place your auction in? jewelry
// ? What would you like your starting bid to be? 50
// Your auction was created successfully!
// ? Would you like to [POST] an auction or [BID] on an auction? BID
// ? What auction would you like to place a bid in? necklace
// ? How much would you like to bid? 40
// Your bid was too low. Try again...
// ? Would you like to [POST] an auction or [BID] on an auction? 
//   POST 
//   BID 
// ❯ EXIT 
// ? Would you like to [POST] an auction or [BID] on an auction? EXIT (after selecting EXIT)
