var mysql = require("mysql");

var connection = mysql.createConnection({
  host: "localhost",

  // Your port; if not 3306
  port: 3306,

  // Your username
  user: "root",

  // Your password (for mySQL workbench)
  password: "lazyjack",
  database: "top_songsDB"
  // database: "ice_creamDB"
});

connection.connect(function(err) {
  if (err) throw err;
  console.log("connected as id " + connection.threadId);
  afterConnection();
});

function afterConnection() {
  // connection.query("SELECT * FROM products", function(err, res) {
  connection.query("SELECT * FROM top5000", function(err, res) {
    if (err) throw err;
    console.log(res);
    connection.end();
  });
}
// where res === results


// REVIEW OF CONCEPTS: To run in node.js, ensure you have changed your password for mySQL: 
// connecting node.js and combining with a database "mysql" npm package
// mysql does not understand JS. mysql just understands SQL
// TO USE mysql npm package, enter the following in the terminal:
  // 1. $ npm init (enter this in command line & keep clicking ENTER). Creates package.json (NOTE: YOU DON'T need to enter npm init if you already have package.json with mysql as a dependency.)
  // 2. $ npm install mysql --save (npm is the Node.js package manager). This downloads the library and installs it in the node_modules folder; and saves it as a DEPENDENCY in package.json file.
  // 3. after installing mysql, the following modules were created: node_modules, package-lock.json, and package.json
  // 4. package.json lists mysql as a dependency

  // We want to have package dependency: 
  // https://nodejs.org/en/docs/meta/topics/dependencies/
  // There are several dependencies that Node.js relies on to work the way it does.
  // Node.js is all about modularity, and with that comes the need for a quality package manager; for this purpose, npm was made. With npm comes the largest selection of community-created packages of any programming ecosystem, which makes building Node.js apps quick and easy.

  // we don't need to share node_modules folder, where mysql is installed


// Enter following in terminal (ensuring you are in same directory) node iceCreamReadData.js
// RETURNS: 
// connected as id 9
// [ RowDataPacket { id: 1, flavor: 'vanilla', price: 2.5, quantity: 100 },
//   RowDataPacket { id: 2, flavor: 'chocolate', price: 3.1, quantity: 120 },
//   RowDataPacket { id: 3, flavor: 'strawberry', price: 3.25, quantity: 75 } ]

// we can change 1) database name from "ice_creamDB" to "top_songsDB" and 2)table name from "products" to "top5000" to return results from entirely different table

// set up database in iceCreamSeeds.sql, make connection with mySQL Workbench/database via iceDCreamReadData.js file, send QUERY via mySQL npm package; results return in JavaScript format to node.js (if on node.js); and then connection ends (see function afterConnection)

// code above is defined in mySQL npm documentation package
