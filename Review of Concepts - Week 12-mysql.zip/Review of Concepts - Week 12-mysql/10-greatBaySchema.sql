DROP DATABASE IF EXISTS greatBay_DB;
CREATE DATABASE greatBay_DB;

USE greatBay_DB;

CREATE TABLE auctions(
  id INT NOT NULL AUTO_INCREMENT,
  item_name VARCHAR(100) NOT NULL,
  category VARCHAR(45) NOT NULL,
  starting_bid INT default 0,
  highest_bid INT default 0,
  PRIMARY KEY (id)
);

-- REVIEW OF CONCEPTS:
-- 1. Need to execute this file greatBaySchema.sql in mySQLWorkbench in order for greatBayBasic.js to be able to access and update database through mysql npm package.
-- 2. similar concepts to prior activities for creating schema. In MySQL, physically, a schema is synonymous with a database. You can substitute the keyword SCHEMA instead of DATABASE in MySQL SQL syntax, for example using CREATE SCHEMA instead of CREATE DATABASE. https://stackoverflow.com/questions/11618277/difference-between-schema-database-in-mysql
