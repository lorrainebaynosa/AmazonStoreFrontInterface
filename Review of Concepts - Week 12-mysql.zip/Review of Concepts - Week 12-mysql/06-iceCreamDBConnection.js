var mysql = require("mysql");

var connection = mysql.createConnection({
  host: "localhost",

  // Your port; if not 3306
  // REVIEW OF CONCEPTS: 3306 is default port for mySQL
  port: 3306,

  // Your username
  user: "root",

  // Your password
  password: "lazyjack",
  database: "ice_creamDB"
});

connection.connect(function(err) {
  if (err) throw err;
  console.log("connected as id " + connection.threadId);
  connection.end();
});

// REVIEW OF CONCEPTS
// connecting node.js and combining with a database "mysql" npm package
// mysql does not understand JS. mysql just understands SQL
// TO USE mysql npm package, enter the following in the terminal:
  // 1. $ npm init (enter this in command line & keep clicking ENTER). Creates package.json (NOTE: YOU DON'T need to enter npm init if you already have package.json with mysql as a dependency.)
  // 2. $ npm install mysql --save (npm is the Node.js package manager). This downloads the library and installs it in the node_modules folder; and saves it as a DEPENDENCY in package.json file.
  // 3. after installing mysql, the following modules were created: node_modules, package-lock.json, and package.json
  // 4. package.json lists mysql as a dependency

  // We want to have package dependency: 
  // https://nodejs.org/en/docs/meta/topics/dependencies/
  // There are several dependencies that Node.js relies on to work the way it does.
  // Node.js is all about modularity, and with that comes the need for a quality package manager; for this purpose, npm was made. With npm comes the largest selection of community-created packages of any programming ecosystem, which makes building Node.js apps quick and easy.

  // we don't need to share node_modules folder, where mysql is installed


// DOCUMENTATION from https://www.npmjs.com/package/mysql

// var mysql      = require('mysql');
// var connection = mysql.createConnection({
//   host     : 'localhost',
//   user     : 'me',
//   password : 'secret',
//   database : 'my_db'
// });
 
// connection.connect();
 
// connection.query('SELECT 1 + 1 AS solution', function (error, results, fields) {
//   if (error) throw error;
//   console.log('The solution is: ', results[0].solution);
// });
 
// connection.end();

// REVIEW OF CONCEPTS: 
// 1. connection is a new object defined in documentation of sql npm package
// 2. this activity just ensures that we have a correct connection
// 3. database specifies the database from mySQLWorkbench that we will be connecting to 
// for connection.query: set up database in .sql, make connection with mySQL Workbench/database via iceCreamDBConnection.js file, send QUERY via mySQL npm package; results return in JavaScript format to node.js (if on node.js); and then connection ends (
// 4. test this code by entering following in terminal
// node iceCreamDBConnection.js
// RETURNS:
// connected as id 56
