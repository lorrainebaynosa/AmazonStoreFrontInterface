-- Drops the favorite_db if it exists currently --
DROP DATABASE IF EXISTS favorite_db;
-- Creates the "favorite_db" database --
CREATE DATABASE favorite_db;

-- Makes it so all of the following code will affect favorite_db --
USE favorite_db;

-- * For the table favorite_foods...
--   * Create the column "food" which can take in a 50 character string and cannot be NULL
--   * Create the column "score" which can take in an integer

-- Creates the table "favorite_foods" within favorite_db --
CREATE TABLE favorite_foods (
  -- Makes a string column called "food" which cannot contain null --
  food VARCHAR(50) NOT NULL,

-- Makes an numeric column called "score" --
  score INTEGER(10)
);

-- * For the table favorite_songs...
-- * Create the column "song" which can take in a 100 character string and cannot be NULL
-- * Create the column "artist" which can take in a 50 character string
-- * Create the column "score" which can take in an integer

CREATE TABLE favorite_songs (
  song VARCHAR(100) NOT NULL,
  artist VARCHAR(50),
  score INTEGER(10)
);

-- For the table favorite_movies...
--   * Create a numeric column called "id" which automatically increments and cannot be null
--   * Create the column "movie" which can take in a string and cannot be NULL
--   * Create the column "five_times" which can take in a boolean
--   * create the column "score" which can take in an integer
--   * Set the primary key of the table to id

CREATE TABLE favorite_movies (
  id INTEGER NOT NULL AUTO_INCREMENT,
  movie VARCHAR(100) NOT NULL,
  -- Creates a boolean column called "five_times" that sets the default value to false if nothing is entered --
  five_times BOOLEAN DEFAULT false,
  score INTEGER(10),
  PRIMARY KEY (id)
);

-- REVIEW OF CONCEPTS: 
-- In MySQL, every statement must be terminated with a semicolon. 
-- shortcut for creating new local instance in mySQLWorkbench: command+SHIFT+T
-- select refresh after executing code in mySQLWorkbench
--SQL uses CLAUSES to dictate what actions should be performed. The CLAUSES are highlighted in BLUE in this activity. ORDER of clauses matters. Specify the following specific to your query:
-- 1. USE [name of database]; must specify the database so you can perform operations on that database
-- 2. SELECT [columns to be included], where * stands for all columns; if you specify specific columns, they will appear sequentially from left to right (i.e., you can dictate how the final table will appear)
-- 3. FROM [table]
-- 4. WHERE [condition to filter data]
-- 5. ORDER BY [column] 
-- 6. LIMIT [number of records you want to display]

-- NOTE THE FOLLOWING DETAILS:
-- 1) all the clause statements end with a semicolon (DROP, CREATE, USE),
-- 2) the columns within CREATE TABLE are contained within a parentheses and column names are noted to the far left within the CREATE TABLE clause
-- 3) NOT NULL precedes AUTO_INCREMENT; however in Activity04, AUTO_INCREMENT precedes NOT NULL: id INTEGER(11) AUTO_INCREMENT NOT NULL, 
-- summary: we have 2 options for ensuring and AUTO_INCREMENT with NOT NULL
-- 4) commas separate the different column descriptions
-- 5) SELECT * FROM favorite_db.favorite_foods: shortcut command for select all columns from the favorite_foods table within the favorite_db database 
-- 6) No values will appear within the cells since code above does not create new rows containing data in all named columns --EXAMPLE:
-- INSERT INTO table name (column_name1,column_name2,column_name3,column_name4)
-- VALUES (value_column1, value_column2, value_column3, value_column4);


-- DATATYPES in SQL: 1) INTEGER (INT); 2) VARCHAR; 3) CHAR; 
-- VARCHAR represents a variable length STRING data type but only holds the characters you assign to it & only stores number of characters needed; (50) === max 50 characters; 
-- VARCHAR (limit) is advisable for efficiency purposes
--score INTEGER(10) === score INT(10), which means data can be up to a maximum of a 10-character integer
-- NOT NULL: By default, a column can hold NULL values. The NOT NULL constraint enforces a column to NOT accept NULL values. This enforces a field to always contain a value, which means that you cannot insert a new record, or update a record without adding a value to this field. https://www.w3schools.com/sql/sql_notnull.asp
-- PRIMARY KEY: a field in a table which uniquely identifies each row/record in a database table. Primary keys must contain unique values. A primary key column cannot have NULL values. A table can have only one primary key, which may consist of single or multiple fields. https://www.tutorialspoint.com/sql/sql-primary-key.htm
-- NOTE syntax for setting primary key to id: PRIMARY KEY (id)



